// Copyright 2015 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef OPENSSL_HEADER_CRYPTO_FIPSMODULE_RAND_INTERNAL_H
#define OPENSSL_HEADER_CRYPTO_FIPSMODULE_RAND_INTERNAL_H

#include <openssl/aes.h>
#include <openssl/ctrdrbg.h>

#include "../../bcm_support.h"
#include "../aes/internal.h"


BSSL_NAMESPACE_BEGIN

// rand_fork_unsafe_buffering_enabled returns whether fork-unsafe buffering has
// been enabled via `RAND_enable_fork_unsafe_buffering`.
int rand_fork_unsafe_buffering_enabled();

BSSL_NAMESPACE_END

// CTR_DRBG_STATE contains the state of a CTR_DRBG based on AES-256. See SP
// 800-90Ar1.
struct ctr_drbg_state_st {
  AES_KEY ks;
  bssl::block128_f block;
  bssl::ctr128_f ctr;
  uint8_t counter[16];
  uint64_t reseed_counter;
  int df;
};

BSSL_NAMESPACE_BEGIN

// CTR_DRBG_init initialises `*drbg` given `entropy_len` bytes of entropy in
// `entropy` and, optionally, a personalization string up to
// `CTR_DRBG_SEED_LEN` bytes in length. It returns one on success and zero on
// error.
//
// If `df` is false then `entropy_len` must be `CTR_DRBG_ENTROPY_LEN` and
// `nonce` must be nullptr.
OPENSSL_EXPORT int CTR_DRBG_init(CTR_DRBG_STATE *drbg, int df,
                                 const uint8_t *entropy, size_t entropy_len,
                                 const uint8_t nonce[CTR_DRBG_NONCE_LEN],
                                 const uint8_t *personalization,
                                 size_t personalization_len);

// BSSL_ENTROPY_DAEMON_RESPONSE_LEN is the number of bytes that the Android
// entropy daemon replies with.
#define BSSL_ENTROPY_DAEMON_RESPONSE_LEN (48 * 10 + 16)

// bssl_get_seed_from_daemon fetches up to `*inout_entropy_len` bytes of
// entropy from the Android entropy daemon, writing them to `*out_entropy`.
// On successful exit, `*inout_entropy_len` contains the number of bytes
// written. Returns one on success and zero on error.
int bssl_get_seed_from_daemon(uint8_t *out_entropy, size_t *inout_entropy_len);

#if defined(OPENSSL_X86_64) && !defined(OPENSSL_NO_ASM)

inline int have_rdrand() { return CRYPTO_is_RDRAND_capable(); }

// have_fast_rdrand returns true if RDRAND is supported and it's reasonably
// fast. Concretely the latter is defined by whether the chip is Intel (fast) or
// not (assumed slow).
inline int have_fast_rdrand() {
  return CRYPTO_is_RDRAND_capable() && CRYPTO_is_intel_cpu();
}

// CRYPTO_rdrand writes eight bytes of random data from the hardware RNG to
// `out`. It returns one on success or zero on hardware failure.
extern "C" int CRYPTO_rdrand(uint8_t out[8]);

// CRYPTO_rdrand_multiple8_buf fills `len` bytes at `buf` with random data from
// the hardware RNG. The `len` argument must be a multiple of eight. It returns
// one on success and zero on hardware failure.
extern "C" int CRYPTO_rdrand_multiple8_buf(uint8_t *buf, size_t len);

#else  // OPENSSL_X86_64 && !OPENSSL_NO_ASM

inline int have_rdrand() { return 0; }

inline int have_fast_rdrand() { return 0; }

#endif  // OPENSSL_X86_64 && !OPENSSL_NO_ASM

BSSL_NAMESPACE_END

#endif  // OPENSSL_HEADER_CRYPTO_FIPSMODULE_RAND_INTERNAL_H
