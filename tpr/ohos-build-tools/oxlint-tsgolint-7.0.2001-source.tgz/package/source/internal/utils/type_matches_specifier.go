package utils

import (
	"errors"
	"fmt"
	"slices"
	"strings"

	"github.com/go-json-experiment/json"
	"github.com/microsoft/typescript-go/shim/ast"
	"github.com/microsoft/typescript-go/shim/checker"
	"github.com/microsoft/typescript-go/shim/compiler"
	"github.com/microsoft/typescript-go/shim/tspath"
)

type TypeOrValueSpecifierFrom uint8

const (
	TypeOrValueSpecifierFromFile TypeOrValueSpecifierFrom = iota
	TypeOrValueSpecifierFromLib
	TypeOrValueSpecifierFromPackage
	TypeOrValueSpecifierFromName
)

type TypeOrValueSpecifier struct {
	From TypeOrValueSpecifierFrom
	Name []string
	// Can be used when From == TypeOrValueSpecifierFromFile
	Path string
	// Can be used when From == TypeOrValueSpecifierFromPackage
	Package string
}

// UnmarshalJSON implements json.Unmarshaler for TypeOrValueSpecifier.
// Handles both string specifiers and object specifiers with "from" field.
func (s *TypeOrValueSpecifier) UnmarshalJSON(data []byte) error {
	// Try to unmarshal as a string first (name-only specifier)
	var str string
	if err := json.Unmarshal(data, &str); err == nil {
		*s = TypeOrValueSpecifier{
			From: TypeOrValueSpecifierFromName,
			Name: []string{str},
		}
		return nil
	}

	// Otherwise, unmarshal as an object
	var raw struct {
		From    string  `json:"from"`
		Name    any     `json:"name"` // Can be string or []string
		Path    *string `json:"path,omitempty"`
		Package *string `json:"package,omitempty"`
	}

	if err := json.Unmarshal(data, &raw); err != nil {
		return fmt.Errorf("TypeOrValueSpecifier must be a string or object with 'from' field: %w", err)
	}

	// Parse the "from" field
	var from TypeOrValueSpecifierFrom
	switch raw.From {
	case "", "file":
		from = TypeOrValueSpecifierFromFile
	case "lib":
		from = TypeOrValueSpecifierFromLib
	case "package":
		from = TypeOrValueSpecifierFromPackage
	default:
		return fmt.Errorf("invalid 'from' field: %s (must be 'file', 'lib', or 'package')", raw.From)
	}

	// Parse the "name" field (can be string or []string)
	var names []string
	switch nameVal := raw.Name.(type) {
	case nil:
		// name field is optional for some specifier types
		names = []string{}
	case string:
		names = []string{nameVal}
	case []any:
		names = make([]string, 0, len(nameVal))
		for _, n := range nameVal {
			if str, ok := n.(string); ok {
				names = append(names, str)
			} else {
				return errors.New("name array must contain only strings")
			}
		}
	default:
		return errors.New("name must be a string or array of strings")
	}

	// Build the result
	*s = TypeOrValueSpecifier{
		From: from,
		Name: names,
	}

	if raw.Path != nil {
		s.Path = *raw.Path
	}
	if raw.Package != nil {
		s.Package = *raw.Package
	}

	return nil
}

// MarshalJSON implements json.Marshaler for TypeOrValueSpecifier.
// Converts the struct back to JSON format compatible with UnmarshalJSON.
func (s TypeOrValueSpecifier) MarshalJSON() ([]byte, error) {
	// Convert From enum to string
	var fromStr string
	switch s.From {
	case TypeOrValueSpecifierFromFile:
		fromStr = "file"
	case TypeOrValueSpecifierFromLib:
		fromStr = "lib"
	case TypeOrValueSpecifierFromPackage:
		fromStr = "package"
	case TypeOrValueSpecifierFromName:
		if len(s.Name) == 1 {
			return json.Marshal(s.Name[0])
		}
		return nil, errors.New("name-only specifier must contain exactly one name")
	default:
		return nil, fmt.Errorf("invalid TypeOrValueSpecifierFrom value: %d", s.From)
	}

	// Build the output object
	output := map[string]any{
		"from": fromStr,
		"name": s.Name,
	}

	if s.Path != "" {
		output["path"] = s.Path
	}
	if s.Package != "" {
		output["package"] = s.Package
	}

	return json.Marshal(output)
}

func typeMatchesStringSpecifier(
	t *checker.Type,
	names []string,
) bool {
	alias := checker.Type_alias(t)
	var symbol *ast.Symbol
	if alias == nil {
		symbol = checker.Type_symbol(t)
	} else {
		symbol = alias.Symbol()
	}

	if symbol != nil && slices.Contains(names, symbol.Name) {
		return true
	}

	if IsIntrinsicType(t) && slices.Contains(names, t.AsIntrinsicType().IntrinsicName()) {
		return true
	}

	return false
}

func typeDeclaredInFile(
	relativePath string,
	declarationFiles []*ast.SourceFile,
	program *compiler.Program,
) bool {
	cwd := program.Host().GetCurrentDirectory()
	if relativePath == "" {
		return Some(declarationFiles, func(f *ast.SourceFile) bool {
			return strings.HasPrefix(f.FileName(), cwd)
		})
	}
	absPath := tspath.GetNormalizedAbsolutePath(relativePath, cwd)
	return Some(declarationFiles, func(f *ast.SourceFile) bool {
		return f.FileName() == absPath
	})
}

func typeDeclaredInLib(
	declarationFiles []*ast.SourceFile,
	program *compiler.Program,
) bool {
	// Assertion: The type is not an error type.

	// Intrinsic type (i.e. string, number, boolean, etc) - Treat it as if it's from lib.
	if len(declarationFiles) == 0 {
		return true
	}
	return Some(declarationFiles, func(d *ast.SourceFile) bool {
		return IsSourceFileDefaultLibrary(program, d)
	})
}

func findParentModuleDeclaration(
	node *ast.Node,
) *ast.ModuleDeclaration {
	switch node.Kind {
	case ast.KindModuleDeclaration:
		decl := node.AsModuleDeclaration()
		// "namespace x {...}" should be ignored here
		if decl.Keyword == ast.KindNamespaceKeyword {
			return findParentModuleDeclaration(node.Parent)
		}

		if ast.IsStringLiteral(decl.Name()) {
			return decl
		}
		return nil
	case ast.KindSourceFile:
		return nil
	default:
		return findParentModuleDeclaration(node.Parent)
	}
}

func typeDeclaredInDeclareModule(
	packageName string,
	declarations []*ast.Node,
) bool {
	return Some(declarations, func(d *ast.Node) bool {
		parentModule := findParentModuleDeclaration(d)
		return parentModule != nil && parentModule.Name().Text() == packageName
	})
}

func getSourceFilePackageName(
	program *compiler.Program,
	sourceFile *ast.SourceFile,
) (string, bool) {
	if program == nil || sourceFile == nil {
		return "", false
	}
	return findSourceFilePackageName(program, sourceFile)
}

func findSourceFilePackageName(
	program *compiler.Program,
	sourceFile *ast.SourceFile,
) (string, bool) {
	fileName := tspath.NormalizeSlashes(sourceFile.FileName())
	if !containsNodeModulesSegment(fileName) {
		return "", false
	}

	if name, ok := findPackageNameFromNearestPackageJSON(program, fileName); ok {
		return name, true
	}

	return findPackageNameFromNodeModulesPath(fileName)
}

func findPackageNameFromNearestPackageJSON(
	program *compiler.Program,
	fileName string,
) (string, bool) {
	fs := program.Host().FS()
	currentDir := tspath.GetDirectoryPath(fileName)
	for currentDir != "" && containsNodeModulesSegment(currentDir) {
		packageJSONPath := tspath.CombinePaths(currentDir, "package.json")
		if contents, ok := fs.ReadFile(packageJSONPath); ok {
			var packageJSON struct {
				Name string `json:"name"`
			}
			if err := json.Unmarshal([]byte(contents), &packageJSON); err == nil && packageJSON.Name != "" {
				return packageJSON.Name, true
			}
		}

		parentDir := tspath.GetDirectoryPath(currentDir)
		if parentDir == currentDir {
			break
		}
		currentDir = parentDir
	}

	return "", false
}

func findPackageNameFromNodeModulesPath(fileName string) (string, bool) {
	segments := strings.Split(tspath.NormalizeSlashes(fileName), "/")
	for i := len(segments) - 1; i >= 0; i-- {
		if segments[i] != "node_modules" {
			continue
		}

		next := i + 1
		if next >= len(segments) {
			continue
		}

		name := segments[next]
		if name == "" || name == "." || name == ".." {
			continue
		}

		if strings.HasPrefix(name, "@") {
			if next+1 < len(segments) && segments[next+1] != "" {
				return name + "/" + segments[next+1], true
			}
			continue
		}

		return name, true
	}

	return "", false
}

func containsNodeModulesSegment(path string) bool {
	normalized := "/" + tspath.NormalizeSlashes(path) + "/"
	return strings.Contains(normalized, "/node_modules/")
}

func typeDeclaredInDeclarationFile(
	packageName string,
	declarationFiles []*ast.SourceFile,
	program *compiler.Program,
) bool {
	if packageName == "" {
		return false
	}

	typesPackageName := getTypesPackageName(packageName)
	return Some(declarationFiles, func(declaration *ast.SourceFile) bool {
		if declaration == nil {
			return false
		}

		packageIdName, ok := getSourceFilePackageName(program, declaration)
		if !ok || packageIdName == "" {
			return false
		}

		return (packageIdName == packageName ||
			packageIdName == typesPackageName ||
			packageIdName == "@types/"+packageName ||
			packageIdName == "@types/"+typesPackageName) &&
			program.IsSourceFileFromExternalLibrary(declaration)
	})
}

func getTypesPackageName(packageName string) string {
	if packageName == "" || packageName[0] != '@' {
		return packageName
	}

	slashIndex := strings.Index(packageName, "/")
	if slashIndex <= 1 || slashIndex+1 >= len(packageName) {
		return packageName
	}

	return packageName[1:slashIndex] + "__" + packageName[slashIndex+1:]
}

func typeDeclaredInPackageDeclarationFile(
	packageName string,
	declarations []*ast.Node,
	declarationFiles []*ast.SourceFile,
	program *compiler.Program,
) bool {
	return typeDeclaredInDeclareModule(packageName, declarations) ||
		typeDeclaredInDeclarationFile(packageName, declarationFiles, program)
}

func typeMatchesSpecifier(
	t *checker.Type,
	specifier TypeOrValueSpecifier,
	program *compiler.Program,
) bool {
	if !typeMatchesStringSpecifier(t, specifier.Name) {
		return false
	}

	symbol := checker.Type_symbol(t)
	if symbol == nil {
		alias := checker.Type_alias(t)
		if alias != nil {
			symbol = alias.Symbol()
		}
	}
	var declarations []*ast.Node
	if symbol != nil {
		declarations = symbol.Declarations
	}
	declarationFiles := Map(declarations, func(d *ast.Node) *ast.SourceFile {
		return ast.GetSourceFileOfNode(d)
	})

	switch specifier.From {
	case TypeOrValueSpecifierFromName:
		return true
	case TypeOrValueSpecifierFromFile:
		return typeDeclaredInFile(specifier.Path, declarationFiles, program)
	case TypeOrValueSpecifierFromLib:
		return typeDeclaredInLib(declarationFiles, program)
	case TypeOrValueSpecifierFromPackage:
		return typeDeclaredInPackageDeclarationFile(specifier.Package, declarations, declarationFiles, program)
	default:
		panic(fmt.Sprintf("unknown type specifier from: %v", specifier.From))
	}
}

// SymbolMatchesSpecifierNameAndSource reports whether a symbol with a known
// static name is allowed by a type-or-value specifier.
//
// This is used when the AST node being checked is not itself a value reference
// with declarations that ValueMatchesSomeSpecifier can inspect. For example,
// contextual object literal properties such as `{ statusCode: 500 }` are checked
// by resolving the `statusCode` property symbol from the target object type, then
// matching that symbol's declaration source against the allow specifier.
func SymbolMatchesSpecifierNameAndSource(
	symbol *ast.Symbol,
	name string,
	specifier TypeOrValueSpecifier,
	program *compiler.Program,
) bool {
	if symbol == nil || !slices.Contains(specifier.Name, name) {
		return false
	}
	declarations := symbol.Declarations
	declarationFiles := Map(declarations, func(d *ast.Node) *ast.SourceFile {
		return ast.GetSourceFileOfNode(d)
	})

	switch specifier.From {
	case TypeOrValueSpecifierFromName:
		return true
	case TypeOrValueSpecifierFromFile:
		return typeDeclaredInFile(specifier.Path, declarationFiles, program)
	case TypeOrValueSpecifierFromLib:
		return typeDeclaredInLib(declarationFiles, program)
	case TypeOrValueSpecifierFromPackage:
		return typeDeclaredInPackageDeclarationFile(specifier.Package, declarations, declarationFiles, program)
	default:
		panic(fmt.Sprintf("unknown value specifier from: %v", specifier.From))
	}
}

// ConvertTypeOrValueSpecifier converts an interface{} (from JSON schema) to a TypeOrValueSpecifier struct.
// The input can be:
// - A string (name-only specifier - matches all declarations with this name)
// - A map with "from" field indicating file/lib/package specifier
func ConvertTypeOrValueSpecifier(spec any) (TypeOrValueSpecifier, bool) {
	// Handle string specifier
	if str, ok := spec.(string); ok {
		return TypeOrValueSpecifier{
			From: TypeOrValueSpecifierFromName,
			Name: []string{str},
		}, true
	}

	// Handle object specifier
	specMap, ok := spec.(map[string]any)
	if !ok {
		return TypeOrValueSpecifier{}, false
	}

	fromStr, ok := specMap["from"].(string)
	if !ok {
		return TypeOrValueSpecifier{}, false
	}

	var from TypeOrValueSpecifierFrom
	switch fromStr {
	case "file":
		from = TypeOrValueSpecifierFromFile
	case "lib":
		from = TypeOrValueSpecifierFromLib
	case "package":
		from = TypeOrValueSpecifierFromPackage
	default:
		return TypeOrValueSpecifier{}, false
	}

	// Extract name(s)
	var names []string
	switch nameVal := specMap["name"].(type) {
	case string:
		names = []string{nameVal}
	case []any:
		names = make([]string, 0, len(nameVal))
		for _, n := range nameVal {
			if str, ok := n.(string); ok {
				names = append(names, str)
			}
		}
	default:
		return TypeOrValueSpecifier{}, false
	}

	result := TypeOrValueSpecifier{
		From: from,
		Name: names,
	}

	// Extract optional path (for file specifiers)
	if pathVal, ok := specMap["path"].(string); ok {
		result.Path = pathVal
	}

	// Extract optional package (for package specifiers)
	if pkgVal, ok := specMap["package"].(string); ok {
		result.Package = pkgVal
	}

	return result, true
}

func TypeMatchesSomeSpecifier(
	t *checker.Type,
	specifiers []TypeOrValueSpecifier,
	program *compiler.Program,
) bool {
	matches := func(t *checker.Type) bool {
		if IsIntrinsicErrorType(t) {
			return false
		}
		return Some(specifiers, func(s TypeOrValueSpecifier) bool {
			return typeMatchesSpecifier(t, s, program)
		})
	}

	if matches(t) {
		return true
	}

	for _, typePart := range IntersectionTypeParts(t) {
		if typePart == t {
			continue
		}
		if matches(typePart) {
			return true
		}
	}
	return false
}

func getStaticName(node *ast.Node) string {
	switch node.Kind {
	case ast.KindIdentifier:
		return node.AsIdentifier().Text
	case ast.KindPrivateIdentifier:
		return strings.TrimPrefix(node.AsPrivateIdentifier().Text, "#")
	case ast.KindStringLiteral:
		return node.Text()
	default:
		return ""
	}
}

func valueMatchesSpecifier(
	node *ast.Node,
	specifier TypeOrValueSpecifier,
	program *compiler.Program,
	t *checker.Type,
) bool {
	nodeName := getStaticName(node)
	if nodeName == "" {
		return false
	}

	// Check if the name matches
	if !slices.Contains(specifier.Name, nodeName) {
		return false
	}

	// Get the source file of the node
	sourceFile := ast.GetSourceFileOfNode(node)
	if sourceFile == nil {
		return false
	}

	if specifier.From == TypeOrValueSpecifierFromPackage {
		symbol := checker.Type_symbol(t)
		if symbol != nil {
			declarationFiles := Map(symbol.Declarations, func(d *ast.Node) *ast.SourceFile {
				return ast.GetSourceFileOfNode(d)
			})

			return typeDeclaredInPackageDeclarationFile(
				specifier.Package,
				symbol.Declarations,
				declarationFiles,
				program,
			)
		}

		// Also check if the type's declarations are from a declare module
		if t != nil {
			symbol := checker.Type_symbol(t)
			if symbol != nil && len(symbol.Declarations) > 0 {
				return typeDeclaredInDeclareModule(specifier.Package, symbol.Declarations)
			}
		}

		return false

	}
	return true
}

func ValueMatchesSomeSpecifier(
	node *ast.Node,
	specifiers []TypeOrValueSpecifier,
	program *compiler.Program,
	ty *checker.Type,
) bool {
	for _, s := range specifiers {
		if valueMatchesSpecifier(
			node,
			s,
			program,
			ty,
		) {
			return true
		}
	}
	return false
}
