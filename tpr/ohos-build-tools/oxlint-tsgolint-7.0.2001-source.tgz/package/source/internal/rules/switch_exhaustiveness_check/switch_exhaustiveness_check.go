package switch_exhaustiveness_check

import (
	"fmt"
	"slices"
	"strings"

	"github.com/dlclark/regexp2/v2"
	"github.com/microsoft/typescript-go/shim/ast"
	"github.com/microsoft/typescript-go/shim/checker"
	"github.com/microsoft/typescript-go/shim/core"
	"github.com/microsoft/typescript-go/shim/scanner"
	"github.com/typescript-eslint/tsgolint/internal/rule"
	"github.com/typescript-eslint/tsgolint/internal/utils"
)

func buildAddMissingCasesMessage() rule.RuleMessage {
	return rule.RuleMessage{
		Id:          "addMissingCases",
		Description: "Add branches for missing cases.",
	}
}

func buildDangerousDefaultCaseMessage() rule.RuleMessage {
	return rule.RuleMessage{
		Id:          "dangerousDefaultCase",
		Description: "The switch statement is exhaustive, so the default case is unnecessary.",
	}
}
func buildSwitchIsNotExhaustiveMessage(missingBranches string) rule.RuleMessage {
	return rule.RuleMessage{
		Id:          "switchIsNotExhaustive",
		Description: "Switch is not exhaustive. Cases not matched: " + missingBranches,
	}
}

type SwitchMetadata struct {
	ContainsNonLiteralType bool
	// Both are nil if there is no default case or matching default-case comment.
	DefaultCase               *ast.CaseOrDefaultClause
	DefaultCaseComment        *ast.CommentRange
	MissingLiteralBranchTypes []*checker.Type
	SymbolName                string
}

func (m *SwitchMetadata) hasDefaultCase() bool {
	return m.DefaultCase != nil || m.DefaultCaseComment != nil
}

func isLiteralLikeType(t *checker.Type) bool {
	return utils.IsTypeFlagSet(
		t,
		checker.TypeFlagsLiteral|checker.TypeFlagsUndefined|checker.TypeFlagsNull|checker.TypeFlagsUniqueESSymbol,
	)
}

/**
 * For example:
 *
 * - `"foo" | "bar"` is a type with all literal types.
 * - `"foo" | number` is a type that contains non-literal types.
 * - `"foo" & { bar: 1 }` is a type that contains non-literal types.
 *
 * Default cases are never superfluous in switches with non-literal types.
 */
func doesTypeContainNonLiteralType(t *checker.Type) bool {
	return utils.Some(
		utils.UnionTypeParts(t),
		func(t *checker.Type) bool {
			return utils.Every(
				utils.IntersectionTypeParts(t),
				func(t *checker.Type) bool {
					return !isLiteralLikeType(t)
				},
			)
		},
	)
}

func getCommentDefaultCase(sourceFile *ast.SourceFile, node *ast.SwitchStatement, commentPattern *regexp2.Regexp) *ast.CommentRange {
	cases := node.CaseBlock.AsCaseBlock().Clauses.Nodes
	if len(cases) == 0 {
		return nil
	}

	commentRange := core.NewTextRange(cases[len(cases)-1].End(), node.CaseBlock.End())
	for comment := range utils.GetCommentsInRange(sourceFile, commentRange) {
		commentText := sourceFile.Text()[comment.Pos():comment.End()]
		switch comment.Kind {
		case ast.KindSingleLineCommentTrivia:
			commentText = strings.TrimPrefix(commentText, "//")
		case ast.KindMultiLineCommentTrivia:
			commentText = strings.TrimSuffix(strings.TrimPrefix(commentText, "/*"), "*/")
		}

		matched, err := commentPattern.MatchString(strings.TrimSpace(commentText))
		if err != nil {
			return nil
		}
		if matched {
			current := comment
			return &current
		}
	}
	return nil
}

func getSwitchMetadata(sourceFile *ast.SourceFile, typeChecker *checker.Checker, node *ast.SwitchStatement, commentPattern *regexp2.Regexp) *SwitchMetadata {
	cases := node.CaseBlock.AsCaseBlock().Clauses.Nodes
	defaultCaseIndex := slices.IndexFunc(cases, ast.IsDefaultClause)
	var defaultCase *ast.CaseOrDefaultClause
	if defaultCaseIndex > -1 {
		defaultCase = cases[defaultCaseIndex].AsCaseOrDefaultClause()
	}
	var defaultCaseComment *ast.CommentRange
	if defaultCase == nil {
		defaultCaseComment = getCommentDefaultCase(sourceFile, node, commentPattern)
	}

	discriminantType := utils.GetConstrainedTypeAtLocation(typeChecker, node.Expression)
	symbolName := ""
	if discriminantType.Symbol() != nil {
		symbolName = discriminantType.Symbol().Name
	}

	caseTypeSet := make(map[*checker.Type]struct{}, len(cases))
	hasUndefinedCase := false
	for _, c := range cases {
		if c.Kind == ast.KindDefaultClause {
			continue
		}

		caseType := utils.GetConstrainedTypeAtLocation(typeChecker, c.AsCaseOrDefaultClause().Expression)
		caseTypeSet[caseType] = struct{}{}
		if utils.IsTypeFlagSet(caseType, checker.TypeFlagsUndefined) {
			hasUndefinedCase = true
		}
	}

	containsNonLiteralType := doesTypeContainNonLiteralType(discriminantType)

	missingLiteralBranchTypes := make([]*checker.Type, 0, 10)
	utils.TypeRecurser(discriminantType, func(t *checker.Type) bool {
		if _, ok := caseTypeSet[t]; ok || !isLiteralLikeType(t) {
			return false
		}

		// "missing", "optional" and "undefined" types are different runtime objects,
		// but all of them have TypeFlags.Undefined type flag
		if hasUndefinedCase && utils.IsTypeFlagSet(t, checker.TypeFlagsUndefined) {
			return false
		}

		missingLiteralBranchTypes = append(missingLiteralBranchTypes, t)

		return false
	})

	return &SwitchMetadata{
		ContainsNonLiteralType:    containsNonLiteralType,
		DefaultCase:               defaultCase,
		DefaultCaseComment:        defaultCaseComment,
		MissingLiteralBranchTypes: missingLiteralBranchTypes,
		SymbolName:                symbolName,
	}
}

func requiresQuoting(text string) bool {
	return !scanner.IsIdentifierText(text, core.LanguageVariantStandard)
}

func getNodeIndent(sourceFile *ast.SourceFile, node *ast.Node) string {
	trimmed := utils.TrimNodeTextRange(sourceFile, node)
	_, column := scanner.GetECMALineAndUTF16CharacterOfPosition(sourceFile, trimmed.Pos())
	if column <= 0 {
		return ""
	}
	return strings.Repeat(" ", int(column))
}

func buildCaseTest(typeChecker *checker.Checker, missingBranchType *checker.Type, symbolName string) string {
	missingBranchName := ""
	if missingBranchType.Symbol() != nil {
		missingBranchName = missingBranchType.Symbol().Name
	}

	caseTest := ""
	if utils.IsTypeFlagSet(missingBranchType, checker.TypeFlagsESSymbolLike) {
		caseTest = missingBranchName
	} else {
		caseTest = typeChecker.TypeToString(missingBranchType)
	}

	if symbolName != "" && requiresQuoting(missingBranchName) {
		return fmt.Sprintf("%s[%s]", symbolName, utils.QuoteSingleStringLiteral(missingBranchName))
	}

	return caseTest
}

func buildMissingCaseLine(typeChecker *checker.Checker, missingBranchType *checker.Type, symbolName string) string {
	if missingBranchType == nil {
		return "default: { throw new Error('default case') }"
	}

	caseTest := buildCaseTest(typeChecker, missingBranchType, symbolName)
	escapedCase := strings.NewReplacer("\\", "\\\\", "'", "\\'").Replace(caseTest)
	return fmt.Sprintf("case %s: { throw new Error('Not implemented yet: %s case') }", caseTest, escapedCase)
}

func buildMissingCases(typeChecker *checker.Checker, missingBranchTypes []*checker.Type, symbolName string) []string {
	missingCases := make([]string, 0, len(missingBranchTypes))
	for _, missingBranchType := range missingBranchTypes {
		missingCases = append(missingCases, buildMissingCaseLine(typeChecker, missingBranchType, symbolName))
	}
	return missingCases
}

func applyMissingCases(sourceFile *ast.SourceFile, node *ast.SwitchStatement, defaultCase *ast.CaseOrDefaultClause, missingCases []string) []rule.RuleFix {
	cases := node.CaseBlock.AsCaseBlock().Clauses.Nodes

	var lastCase *ast.Node
	if len(cases) > 0 {
		lastCase = cases[len(cases)-1]
	}

	caseIndent := ""
	if lastCase != nil {
		caseIndent = getNodeIndent(sourceFile, lastCase)
	} else {
		caseIndent = getNodeIndent(sourceFile, &node.Node)
	}

	fixString := ""
	if len(missingCases) > 0 {
		indented := make([]string, 0, len(missingCases))
		for _, code := range missingCases {
			indented = append(indented, caseIndent+code)
		}
		fixString = strings.Join(indented, "\n")
	}

	if lastCase != nil {
		if defaultCase != nil {
			beforeFixBuilder := strings.Builder{}
			for _, code := range missingCases {
				beforeFixBuilder.WriteString(code)
				beforeFixBuilder.WriteByte('\n')
				beforeFixBuilder.WriteString(caseIndent)
			}

			return []rule.RuleFix{
				rule.RuleFixInsertBefore(sourceFile, &defaultCase.Node, beforeFixBuilder.String()),
			}
		}

		return []rule.RuleFix{
			rule.RuleFixInsertAfter(lastCase, "\n"+fixString),
		}
	}

	return []rule.RuleFix{
		rule.RuleFixReplace(
			sourceFile,
			node.CaseBlock,
			strings.Join([]string{"{", fixString, caseIndent + "}"}, "\n"),
		),
	}
}

func fixSwitch(sourceFile *ast.SourceFile, typeChecker *checker.Checker, node *ast.SwitchStatement, missingBranchTypes []*checker.Type, defaultCase *ast.CaseOrDefaultClause, symbolName string) []rule.RuleFix {
	missingCases := buildMissingCases(typeChecker, missingBranchTypes, symbolName)
	return applyMissingCases(sourceFile, node, defaultCase, missingCases)
}

var SwitchExhaustivenessCheckRule = rule.Rule{
	Name: "switch-exhaustiveness-check",
	Run: func(ctx rule.RuleContext, options any) rule.RuleListeners {
		opts := utils.UnmarshalOptions[SwitchExhaustivenessCheckOptions](options, "switch-exhaustiveness-check")
		commentPattern := regexp2.MustCompile("^no default$", regexp2.ECMAScript|regexp2.Unicode|regexp2.IgnoreCase)
		if opts.DefaultCaseCommentPattern != nil {
			commentPattern = regexp2.MustCompile(*opts.DefaultCaseCommentPattern, regexp2.ECMAScript|regexp2.Unicode)
		}

		checkSwitchExhaustive := func(node *ast.SwitchStatement, switchMetadata *SwitchMetadata) {
			// If considerDefaultExhaustiveForUnions is enabled, the presence of a default case
			// always makes the switch exhaustive.
			if opts.ConsiderDefaultExhaustiveForUnions && switchMetadata.hasDefaultCase() {
				return
			}

			if len(switchMetadata.MissingLiteralBranchTypes) > 0 {
				missingBranches := make([]string, 0, len(switchMetadata.MissingLiteralBranchTypes))
				for _, missingType := range switchMetadata.MissingLiteralBranchTypes {
					if utils.IsTypeFlagSet(missingType, checker.TypeFlagsESSymbolLike) && missingType.Symbol() != nil {
						missingBranches = append(missingBranches, "typeof "+missingType.Symbol().Name)
						continue
					}

					missingBranches = append(missingBranches, ctx.TypeChecker.TypeToString(missingType))
				}

				ctx.ReportNodeWithSuggestions(node.Expression, buildSwitchIsNotExhaustiveMessage(strings.Join(missingBranches, " | ")), func() []rule.RuleSuggestion {
					return []rule.RuleSuggestion{{
						Message:  buildAddMissingCasesMessage(),
						FixesArr: fixSwitch(ctx.SourceFile, ctx.TypeChecker, node, switchMetadata.MissingLiteralBranchTypes, switchMetadata.DefaultCase, switchMetadata.SymbolName),
					}}
				})
			}
		}

		checkSwitchUnnecessaryDefaultCase := func(switchMetadata *SwitchMetadata) {
			if opts.AllowDefaultCaseForExhaustiveSwitch {
				return
			}

			if len(switchMetadata.MissingLiteralBranchTypes) == 0 &&
				switchMetadata.hasDefaultCase() &&
				!switchMetadata.ContainsNonLiteralType {
				if switchMetadata.DefaultCaseComment != nil {
					ctx.ReportRange(switchMetadata.DefaultCaseComment.TextRange, buildDangerousDefaultCaseMessage())
				} else {
					ctx.ReportNode(&switchMetadata.DefaultCase.Node, buildDangerousDefaultCaseMessage())
				}
			}
		}
		checkSwitchNoUnionDefaultCase := func(node *ast.SwitchStatement, switchMetadata *SwitchMetadata) {
			if !opts.RequireDefaultForNonUnion {
				return
			}

			if switchMetadata.ContainsNonLiteralType && !switchMetadata.hasDefaultCase() {
				ctx.ReportNodeWithSuggestions(node.Expression, buildSwitchIsNotExhaustiveMessage("default"), func() []rule.RuleSuggestion {
					return []rule.RuleSuggestion{{
						Message:  buildAddMissingCasesMessage(),
						FixesArr: fixSwitch(ctx.SourceFile, ctx.TypeChecker, node, []*checker.Type{nil}, switchMetadata.DefaultCase, switchMetadata.SymbolName),
					}}
				})
			}
		}

		return rule.RuleListeners{
			ast.KindSwitchStatement: func(node *ast.Node) {

				stmt := node.AsSwitchStatement()

				metadata := getSwitchMetadata(ctx.SourceFile, ctx.TypeChecker, stmt, commentPattern)
				checkSwitchExhaustive(stmt, metadata)
				checkSwitchUnnecessaryDefaultCase(metadata)
				checkSwitchNoUnionDefaultCase(stmt, metadata)
			},
		}

	},
}
