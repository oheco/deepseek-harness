var varDeclarationFromFixture = 1;
