# `@oxc-resolver/binding-openharmony-arm64`

This is the **aarch64-unknown-linux-ohos** binary for `@oxc-resolver/binding`
